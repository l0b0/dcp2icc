To build the DNG SDK, you also need to download and install the Adobe XMP SDK. It is available from:

http://www.adobe.com/devnet/xmp/

The XMP-SDK folder should be placed next to the dng_sdk folder (i.e. as a sibling of this read-me file).

Note that the current XMP SDK also requires you to download in install expat.  It is available from:

http://sourceforge.net/projects/expat/

For more information on installing expat into the XMP SDK, see the read-me file inside the XMP SDK:

XMP-SDK/third-party/expat/ReadMe.txt
